import cv2 as cv
import supervision as sv
from ultralytics import YOLO


# Load the YOLO model
model = YOLO('best (3).pt')

# Create annotators
bounding_box_annotator = sv.BoxAnnotator()  # Use BoxAnnotator instead of BoundingBoxAnnotator
label_annotator = sv.LabelAnnotator()

# Start video capture
cap = cv.VideoCapture(0)

if not cap.isOpened():
    print("Unable to read camera feed")
    exit(1)

while True:
    ret, frame = cap.read()

    if not ret: 
        print("Failed to grab frame")
        break

    # Process the frame with the YOLO model
    results = model(frame)[0]
    detections = sv.Detections.from_ultralytics(results)

    # Annotate the frame with bounding boxes and labels
    annotated_image = bounding_box_annotator.annotate(scene=frame, detections=detections)
    annotated_image = label_annotator.annotate(scene=annotated_image, detections=detections)

    # Display the annotated image
    cv.imshow('Webcam', annotated_image)

    # Exit on 'Esc' key press
    k = cv.waitKey(1)
    if k % 256 == 27:
        print("Escape hit, closing..")
        break



rgb_frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
results = model(rgb_frame)[0]

# Release the capture and destroy windows
cap.release()
cv.destroyAllWindows()
resized_frame = cv.resize(rgb_frame, (640, 480))
