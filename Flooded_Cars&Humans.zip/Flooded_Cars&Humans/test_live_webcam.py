import unittest
import cv2
from ultralytics import YOLO
import time


class TestLiveWebcamDetection(unittest.TestCase):
    def setUp(self):
        """Set up the YOLO model and webcam for testing."""
        self.model = YOLO('best (2).pt')  # Replace with your model path
        self.capture = cv2.VideoCapture(0)  # Open the webcam

        if not self.capture.isOpened():
            self.fail("Unable to access webcam")

    def tearDown(self):
        """Release resources after testing."""
        self.capture.release()
        cv2.destroyAllWindows()

    def test_detect_human_in_flood_live(self):
        """Test if the model detects a human in flood via webcam."""
        test_duration = 60  # Run the test for 60 seconds
        end_time = time.time() + test_duration
        detected_human_in_flood = False

        while time.time() < end_time:
            ret, frame = self.capture.read()
            if not ret:
                self.fail("Failed to read frame from webcam")

            # Perform detection
            results = self.model(frame)[0]
            detections = results.boxes

            # Check for the label "human in flood"
            for box in detections:
                label = results.names[int(box.cls[0])]
                if label == "human in flood":
                    detected_human_in_flood = True
                    break

            if detected_human_in_flood:
                break  # Stop if detected

        # Log the test result
        if detected_human_in_flood:
            print("Test Result: PASS - Detected 'human in flood'")
        else:
            print("Test Result: FAIL - Could not detect 'human in flood'")

        self.assertTrue(detected_human_in_flood, "Model failed to detect 'human in flood' live")

    def test_detect_flooded_car_live(self):
        """Test if the model detects a flooded car via webcam."""
        test_duration = 60  # Run the test for 60 seconds
        end_time = time.time() + test_duration
        detected_flooded_car = False

        while time.time() < end_time:
            ret, frame = self.capture.read()
            if not ret:
                self.fail("Failed to read frame from webcam")

            # Perform detection
            results = self.model(frame)[0]
            detections = results.boxes

            # Check for the label "flooded car"
            for box in detections:
                label = results.names[int(box.cls[0])]
                if label == "flooded car":
                    detected_flooded_car = True
                    break

            if detected_flooded_car:
                break  # Stop if detected

        # Log the test result
        if detected_flooded_car:
            print("Test Result: PASS - Detected 'flooded car'")
        else:
            print("Test Result: FAIL - Could not detect 'flooded car'")

        self.assertTrue(detected_flooded_car, "Model failed to detect 'flooded car' live")


if __name__ == '__main__':
    unittest.main()
