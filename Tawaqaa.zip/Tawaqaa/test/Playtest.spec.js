test('Test Fetch Data from Firebase', async ({ page }) => {
    // التأكد من أن الجدول يحتوي على بيانات
    const tableRows = await page.locator('table tbody tr').all();
  
    // التحقق إذا تم جلب البيانات بشكل صحيح
    expect(tableRows.length).toBeGreaterThan(0); // التأكد من وجود بيانات في الجدول
  });
  
  test('Test Delete Report', async ({ page }) => {
    // تأكد من أن الزر موجود في الصف الأول
    const deleteButton = page.locator('table tbody tr:first-child button.delete');
    
    // الانتظار حتى يصبح الزر قابلًا للنقر
    await deleteButton.waitFor({ state: 'visible' });
  
    // تنفيذ عملية الحذف
    await deleteButton.click();
  
    // التحقق من ظهور نافذة التأكيد
    const confirmationDialog = page.locator('text=هل أنت متأكد أنك تريد حذف الإنذار؟');
    await confirmationDialog.waitFor({ state: 'visible' });
  
    // قبول الحذف
    await page.locator('text=نعم').click(); // تعديل النص حسب النص الظاهر في نافذة التأكيد
  
    // التأكد من أن الصف تم حذفه بعد النقر
    const tableRowsAfterDelete = await page.locator('table tbody tr').all();
    expect(tableRowsAfterDelete.length).toBeLessThan(tableRows.length); // التحقق من أن الصف تم حذفه
  });
  
  test('Test Confirmation Dialog', async ({ page }) => {
    // تأكد من وجود الزر المطلوب للحذف
    const deleteButton = page.locator('table tbody tr:first-child button.delete');
    await deleteButton.waitFor({ state: 'visible' });
  
    // النقر على زر الحذف
    await deleteButton.click();
  
    // التحقق من ظهور نافذة التأكيد
    const confirmationDialog = page.locator('text=هل أنت متأكد أنك تريد حذف الإنذار؟');
    await confirmationDialog.waitFor({ state: 'visible' });
  
    // النقر على "نعم" لتأكيد الحذف
    await page.locator('text=نعم').click();
  
    // التأكد من أن الصف تم حذفه
    const tableRowsAfterDelete = await page.locator('table tbody tr').all();
    expect(tableRowsAfterDelete.length).toBeLessThan(0);
  });
  
  test('Test Notification Display', async ({ page }) => {
    // تأكد من وجود الزر المطلوب للحذف
    const deleteButton = page.locator('table tbody tr:first-child button.delete');
    await deleteButton.waitFor({ state: 'visible' });
  
    // النقر على زر الحذف
    await deleteButton.click();
  
    // التأكد من ظهور نافذة التأكيد
    const confirmationDialog = page.locator('text=هل أنت متأكد أنك تريد حذف الإنذار؟');
    await confirmationDialog.waitFor({ state: 'visible' });
  
    // النقر على "نعم" لتأكيد الحذف
    await page.locator('text=نعم').click();
  
    const notification = page.locator('text=تم الحذف بنجاح');
    await notification.waitFor({ state: 'visible' });
  
 
    expect(await notification.textContent()).toBe('تم الحذف بنجاح');
  });
  