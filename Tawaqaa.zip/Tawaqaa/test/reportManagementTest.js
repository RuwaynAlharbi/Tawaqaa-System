import { expect } from 'chai';
import sinon from 'sinon';
import jsdom from 'jsdom';

// Mock the DOM environment using jsdom
const { JSDOM } = jsdom;
const dom = new JSDOM(`
  <html lang="ar">
    <body>
      <table id="myTable">
        <thead>
          <tr>
            <th>الوقت</th>
            <th>عدد البلاغات</th>
            <th>مستوى المياه</th>
            <th>خط العرض</th>
            <th>خط الطول</th>
            <th>الشارع</th>
            <th>مستوى الخطر</th>
            <th></th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </body>
  </html>
`);
global.document = dom.window.document;
global.window = dom.window;

// Sample report data
const reportData = [
    {
        time: "-",
        count: 5,
        latitude: "21.5541",
        longitude: "39.1911",
        street: "شارع حراء",
        riskLevel: "عالي",
        id: 1
    },
    {
        time: "-",
        count: 1,
        latitude: "21.5632",
        longitude: "39.1816",
        street: "شارع قريش",
        riskLevel: "متوسط",
        id: 2
    }
];

// Function to test: Add Row to Table
function addRowToTable(report) {
    const tableBody = document.querySelector("#myTable tbody");
    const tableRow = document.createElement("tr");
    tableRow.innerHTML = `
        <td>${report.time}</td>
        <td>${report.count}</td>
        <td>-</td>
        <td>${report.latitude}</td>
        <td>${report.longitude}</td>
        <td>${report.street}</td>
        <td class="${report.riskLevel === 'عالي' ? 'high-risk' : report.riskLevel === 'متوسط' ? 'medium-risk' : 'low-risk'}">${report.riskLevel}</td>
        <td><button class="deleteBtn" data-id="${report.id}">حذف</button></td>
    `;
    tableBody.appendChild(tableRow);
}

// Function to test: Check for Duplicate Reports
function isDuplicateReport(newReport, existingReports) {
    return existingReports.some(report => report.latitude === newReport.latitude && report.longitude === newReport.longitude && report.street === newReport.street);
}

// Function to test: Highlight Rows Based on Risk Level
function highlightRows() {
    const rows = document.querySelectorAll('#myTable tbody tr');
    rows.forEach(row => {
        const riskLevelCell = row.cells[6]; // The risk level is in the 7th cell (index 6)
        const riskLevel = riskLevelCell.textContent;
        if (riskLevel === 'عالي') {
            riskLevelCell.classList.add('high-risk');
        } else if (riskLevel === 'متوسط') {
            riskLevelCell.classList.add('medium-risk');
        } else {
            riskLevelCell.classList.add('low-risk');
        }
    });
}

// Mocha Unit Tests
describe('Unit Tests for Report Management', () => {

    // Test: Add Row To Table
    it('should add a new row to the table', () => {
        const initialRowCount = document.querySelectorAll("#myTable tbody tr").length;
        addRowToTable(reportData[0]); // Add a row
        const newRowCount = document.querySelectorAll("#myTable tbody tr").length;
        expect(newRowCount).to.equal(initialRowCount + 1); // Check that a row was added
    });

    // Test: Is Duplicate Report (True)
    it('should return true if the report is a duplicate', () => {
        const newReport = {
            latitude: "21.5541",
            longitude: "39.1911",
            street: "شارع حراء"
        };
        const result = isDuplicateReport(newReport, reportData);
        expect(result).to.be.true; // Expect the result to be true as it matches an existing report
    });

    // Test: Is Duplicate Report (False)
    it('should return false if the report is not a duplicate', () => {
        const newReport = {
            latitude: "21.0000",
            longitude: "39.0000",
            street: "شارع الملك"
        };
        const result = isDuplicateReport(newReport, reportData);
        expect(result).to.be.false; // Expect the result to be false as it doesn’t match any report
    });

    // Test: Highlight Rows
    it('should apply appropriate highlight classes based on risk level', () => {
        addRowToTable(reportData[0]); // Add a high-risk row
        addRowToTable(reportData[1]); // Add a medium-risk row
        highlightRows(); // Apply the highlight

        const rows = document.querySelectorAll('#myTable tbody tr');
        const highRiskRow = rows[0];
        const mediumRiskRow = rows[1];

        // Check that high-risk row has the correct class
        expect(highRiskRow.cells[6].classList.contains('high-risk')).to.be.true;
        // Check that medium-risk row has the correct class
        expect(mediumRiskRow.cells[6].classList.contains('medium-risk')).to.be.true;
    });

});

