/*

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getDatabase, ref, get, remove } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCdBCKr9JEKCkNao2U4eW3PY9qcMRWRyDU",
    authDomain: "toauqa.firebaseapp.com",
    databaseURL: "https://toauqa-default-rtdb.firebaseio.com",
    projectId: "toauqa",
    storageBucket: "toauqa.appspot.com",
    messagingSenderId: "292605742833",
    appId: "1:292605742833:web:09fdef3d3aa4a66d19e350",
    measurementId: "G-SCNZBW9NLN",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Elements for confirmation dialog
const confirmationDialog = document.getElementById("confirmationDialog");
const confirmButton = document.getElementById("confirmButton");
const cancelButton = document.getElementById("cancelButton");

// Elements for notification
const notification = document.getElementById("notification");
const notificationMessage = notification.querySelector("p");

// Variable to store the report ID to delete
let reportIdToDelete = null;

/**
 * Show the confirmation dialog for deletion.
 * @param {string} reportId - The ID of the report to delete.
 
function showConfirmationDialog(reportId) {
    reportIdToDelete = reportId;
    confirmationDialog.style.display = "block";
}

/**
 * Hide the confirmation dialog.
 
function hideConfirmationDialog() {
    reportIdToDelete = null;
    confirmationDialog.style.display = "none";
}

/**
 * Show a notification message.
 * @param {string} message - The message to display.
 
function showNotification(message) {
    notificationMessage.textContent = message;
    notification.style.display = "block";
    setTimeout(() => {
        notification.style.display = "none";
    }, 3000);
}

/**
 * Determine risk level based on the count of reports for a specific location and street.
 * @param {number} count - The number of reports for the same location and street.
 * @returns {string} - Risk level as 'عالي', 'متوسط', or 'منخفض'.
 
function getRiskLevel(count) {
    if (count >= 3) {
        return "عالي";
    } else if (count > 0) {
        return "متوسط";
    }
    return "منخفض";
}

/**
 * Delete a report from Firebase.
 * @param {string} reportId - The ID of the report to delete.
 
function deleteReport(reportId) {
    const reportRef = ref(database, `Reports/${reportId}`);
    remove(reportRef)
        .then(() => {
            showNotification("تم الحذف بنجاح");
            fetchDataFromFirebase(); // Reload data after deletion
        })
        .catch((error) => {
            console.error("Error deleting report:", error);
        });
}

/**
 * Add click event listeners to delete buttons.
 
function addDeleteListeners() {
    document.querySelectorAll(".deleteBtn").forEach((button) => {
        button.addEventListener("click", (event) => {
            const reportId = event.target.getAttribute("data-id");
            showConfirmationDialog(reportId);
        });
    });
}

/**
 * Fetch data from Firebase and populate the table.
 
function fetchDataFromFirebase() {
    const dbRef = ref(database, "Reports");
    get(dbRef)
        .then((snapshot) => {
            if (snapshot.exists()) {
                const tableBody = document.querySelector("#myTable tbody");
                tableBody.innerHTML = ""; // Clear existing rows

                const reportAggregates = {}; // Aggregate reports by location and street

                snapshot.forEach((childSnapshot) => {
                    const report = childSnapshot.val();
                    const reportId = childSnapshot.key;

                    // Create a unique key for the location and street
                    const uniqueKey = `${report.latitude}-${report.longitude}-${report.nameStreet}`;

                    if (!reportAggregates[uniqueKey]) {
                        reportAggregates[uniqueKey] = {
                            count: 0,
                            latitude: report.latitude,
                            longitude: report.longitude,
                            nameStreet: report.nameStreet,
                            waterLevel: report.waterLevel || "-",
                            reportIds: [],
                        };
                    }

                    // Increment the count and add the report ID
                    reportAggregates[uniqueKey].count++;
                    reportAggregates[uniqueKey].reportIds.push(reportId);
                });

                // Populate the table
                Object.values(reportAggregates).forEach((aggregate) => {
                    const riskLevel = getRiskLevel(aggregate.count);
                    const tableRow = document.createElement("tr");
                    tableRow.innerHTML = `
                        <td>${aggregate.count}</td>
                        <td>${aggregate.waterLevel}</td>
                        <td>${aggregate.latitude}</td>
                        <td>${aggregate.longitude}</td>
                        <td>${aggregate.nameStreet}</td>
                        <td class="${riskLevel === 'عالي' ? 'high-risk' : riskLevel === 'متوسط' ? 'medium-risk' : 'low-risk'}">${riskLevel}</td>
                        <td>
                            ${aggregate.reportIds.map((id) => `<button class="deleteBtn" data-id="${id}">حذف</button>`).join(" ")}
                        </td>
                    `;
                    tableBody.appendChild(tableRow);
                });

                // Add delete button listeners
                addDeleteListeners();
            }
        })
        .catch((error) => {
            console.error("Error fetching data:", error);
        });
}

// Handle confirm button click
confirmButton.addEventListener("click", () => {
    if (reportIdToDelete) {
        deleteReport(reportIdToDelete);
    }
    hideConfirmationDialog();
});

// Handle cancel button click
cancelButton.addEventListener("click", hideConfirmationDialog);

// Fetch data on page load
fetchDataFromFirebase();*/
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getDatabase, ref, get, remove } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCdBCKr9JEKCkNao2U4eW3PY9qcMRWRyDU",
    authDomain: "toauqa.firebaseapp.com",
    databaseURL: "https://toauqa-default-rtdb.firebaseio.com",
    projectId: "toauqa",
    storageBucket: "toauqa.appspot.com",
    messagingSenderId: "292605742833",
    appId: "1:292605742833:web:09fdef3d3aa4a66d19e350",
    measurementId: "G-SCNZBW9NLN",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Elements for confirmation dialog
const confirmationDialog = document.getElementById("confirmationDialog");
const confirmButton = document.getElementById("confirmButton");
const cancelButton = document.getElementById("cancelButton");

// Elements for notification
const notification = document.getElementById("notification");
const notificationMessage = notification.querySelector("p");

// Variable to store the report IDs to delete
let reportIdsToDelete = [];

/**
 * Show the confirmation dialog for deletion.
 * @param {Array<string>} reportIds - The IDs of the reports to delete.
 */
function showConfirmationDialog(reportIds) {
    reportIdsToDelete = reportIds;
    confirmationDialog.style.display = "block";
}

/**
 * Hide the confirmation dialog.
 */
function hideConfirmationDialog() {
    reportIdsToDelete = [];
    confirmationDialog.style.display = "none";
}

/**
 * Show a notification message.
 * @param {string} message - The message to display.
 */
function showNotification(message) {
    notificationMessage.textContent = message;
    notification.style.display = "block";
    setTimeout(() => {
        notification.style.display = "none";
    }, 3000);
}

/**
 * Determine risk level based on the count of reports for a specific location and street.
 * @param {number} count - The number of reports for the same location and street.
 * @returns {string} - Risk level as 'عالي', 'متوسط', or 'منخفض'.
 */
function getRiskLevel(count) {
    if (count >= 3) {
        return "عالي";
    } else if (count > 0) {
        return "متوسط";
    }
    return "منخفض";
}

/**
 * Delete reports from Firebase.
 * @param {Array<string>} reportIds - The IDs of the reports to delete.
 */
function deleteReports(reportIds) {
    const promises = reportIds.map((reportId) => {
        const reportRef = ref(database, `Reports/${reportId}`);
        return remove(reportRef);
    });

    Promise.all(promises)
        .then(() => {
            showNotification("تم الحذف بنجاح");
            fetchDataFromFirebase(); // Reload data after deletion
        })
        .catch((error) => {
            console.error("Error deleting reports:", error);
        });
}

/**
 * Fetch data from Firebase and populate the table.
 */
function fetchDataFromFirebase() {
    const dbRef = ref(database, "Reports");
    get(dbRef)
        .then((snapshot) => {
            if (snapshot.exists()) {
                const tableBody = document.querySelector("#myTable tbody");
                tableBody.innerHTML = ""; // Clear existing rows

                const reportAggregates = {}; // Aggregate reports by location and street

                snapshot.forEach((childSnapshot) => {
                    const report = childSnapshot.val();
                    const reportId = childSnapshot.key;

                    // Create a unique key for the location and street
                    const uniqueKey = `${report.latitude}-${report.longitude}-${report.nameStreet}`;

                    if (!reportAggregates[uniqueKey]) {
                        reportAggregates[uniqueKey] = {
                            count: 0,
                            latitude: report.latitude,
                            longitude: report.longitude,
                            nameStreet: report.nameStreet,
                            waterLevel: report.waterLevel || "-",
                            reportIds: [],
                        };
                    }

                    // Increment the count and add the report ID
                    reportAggregates[uniqueKey].count++;
                    reportAggregates[uniqueKey].reportIds.push(reportId);
                });

                // Populate the table
                Object.values(reportAggregates).forEach((aggregate) => {
                    const riskLevel = getRiskLevel(aggregate.count);
                    const tableRow = document.createElement("tr");
                    tableRow.innerHTML = `
                        <td>${aggregate.count}</td>
                        <td>${aggregate.waterLevel}</td>
                        <td>${aggregate.latitude}</td>
                        <td>${aggregate.longitude}</td>
                        <td>${aggregate.nameStreet}</td>
                        <td class="${riskLevel === 'عالي' ? 'high-risk' : riskLevel === 'متوسط' ? 'medium-risk' : 'low-risk'}">${riskLevel}</td>
                        <td>
                            <button class="deleteBtn" data-ids="${aggregate.reportIds.join(",")}">حذف</button>
                        </td>
                    `;
                    tableBody.appendChild(tableRow);
                });

                // Add delete button listeners
                addDeleteListeners();
            }
        })
        .catch((error) => {
            console.error("Error fetching data:", error);
        });
}

/**
 * Add click event listeners to delete buttons.
 */
function addDeleteListeners() {
    document.querySelectorAll(".deleteBtn").forEach((button) => {
        button.addEventListener("click", (event) => {
            const reportIds = event.target.getAttribute("data-ids").split(",");
            showConfirmationDialog(reportIds);
        });
    });
}

// Handle confirm button click
confirmButton.addEventListener("click", () => {
    if (reportIdsToDelete.length > 0) {
        deleteReports(reportIdsToDelete);
    }
    hideConfirmationDialog();
});

// Handle cancel button click
cancelButton.addEventListener("click", hideConfirmationDialog);

// Fetch data on page load
fetchDataFromFirebase();
